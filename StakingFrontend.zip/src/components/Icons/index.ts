export { default as Dashboard } from "./Dashboard";
export { default as Buy } from "./Buy";
export { default as Discord } from "./Discord";
export { default as Twitter } from "./Twitter";
export { default as Stake } from "./Stake";
export { default as Whitepaper } from "./Whitepaper";
export { default as Wallet } from "./Wallet";
export { default as Info } from "./Info";
